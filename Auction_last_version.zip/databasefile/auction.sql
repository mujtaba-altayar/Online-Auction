-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2023 at 12:04 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `auction`
--

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `adsID` int(11) NOT NULL,
  `productname` varchar(255) NOT NULL,
  `image` varchar(500) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `description` varchar(1500) NOT NULL,
  `price` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `end_date` date NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`adsID`, `productname`, `image`, `userid`, `description`, `price`, `category_id`, `end_date`, `status`) VALUES
(1, 'Renge Rover', 'renge.jpg', '1', 'range rover  | 10v | 280km', '80000', 1, '2023-07-10', 'جيد'),
(2, 'Mercedce Benz', '018e2942-ec84-4a7d-8061-18ddd6242b12.jpeg', '1', 'ممشي 10الف متر | اللون ذهبي | الموديل 2021', '175000', 1, '2023-07-25', 'ممتاز'),
(3, 'Meredece GMT', 'automobile-g6685246b2_1920.jpg', '1', 'سيارة خضراء | ميرسيدس | عداد 340 كم\\س                     ', '300000', 1, '2023-07-11', 'مستعملة'),
(4, 'شيفرليه كامارو', 'automobile-g01592abbf_1280.jpg', '1', 'سيارة كلاسيكية موديل 1980          ', '2000000', 1, '2023-07-11', 'قديمة'),
(5, 'testing', '4be74566-1520-42e0-9745-6529a0986aec.jpeg', '1', 'biding car', '00000', 1, '2023-07-19', 'testing'),
(6, 'smart tv', 'lcd-16756.png', '1', 'tv with 32inches samsung', '562000', 3, '2023-07-11', 'جديد'),
(7, 'كرسي', 'chair-13221.png', '1', 'كرسي مكتبي رمادي اللون     ', '90000', 2, '2023-07-11', 'جديد'),
(8, 'testing car', '018e2942-ec84-4a7d-8061-18ddd6242b12.jpeg', '1', 'testing car', '0', 1, '2023-07-12', 'new');

-- --------------------------------------------------------

--
-- Table structure for table `bids`
--

CREATE TABLE `bids` (
  `bidID` int(11) NOT NULL,
  `price` varchar(255) CHARACTER SET utf8 NOT NULL,
  `bid_date` date NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `user_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `address` varchar(25) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `username`, `password`, `email`, `phone`, `address`, `status`) VALUES
(1, 'mujtaba', 'admin123', 'qusai7000.ma@gmail.com', '0926537665', 'wad-madani', 1),
(2, 'mohammed', '123', 'mohammed@gmail.com', '0123784378', 'khartoum', 0),
(3, 'yassen', 'yassen123', 'yassen123@gmail.com', '0994876232', 'middle-mayo', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`adsID`);

--
-- Indexes for table `bids`
--
ALTER TABLE `bids`
  ADD PRIMARY KEY (`bidID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `adsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `bids`
--
ALTER TABLE `bids`
  MODIFY `bidID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
