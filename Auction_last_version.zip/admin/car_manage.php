<?php
session_start();
include_once 'connection.php';
include "indexheader.php";
?>



<body dir="rtl">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="#!">
                المزاد الالكتروني
            </a>
            <form class="d-flex">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <li class="nav-item">
                        <?php

                        if (isset($_SESSION['user'])) {
                            echo '<a class="nav-link" href="logout.php"> تسجيل خروج ';
                            echo "</a>";
                        } else {
                            echo '<a class="nav-link" href="login.php"> تسجيل دخول';
                        }
                        ?>
                    </li>
                </ul>
            </form>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div style="flex-direction: row-reverse;" class="collapse navbar-collapse" id="navbarSupportedContent">
                <form class="d-flex">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link" href="viewfurns.php">الاثاثات</a></li>
                        <li class="nav-item"><a class="nav-link" href="viewcars.php">السيارات</a></li>
                        <li class="nav-item"><a class="nav-link" href="viewelectonics.php">الاجهزة الالكترونية</a></li>
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="dashboard.php">الرئيسية</a></li>
                    </ul>
                </form>
            </div>
        </div>
    </nav>

    <!-- Header-->
    <header class="bg-dark py-5">
        <div class="container px-3 px-lg-3">
            <div class="text-center text-white">
                <h1 class="display-4 fw-bolder">اضافة سيارة للمزاد</h1>
            </div>
        </div>
    </header>

    <?php

    $do  = isset($_GET['do']) ? $_GET['do'] : 'dashboard';
    if ($do == 'Add') {


    ?>

        <!-- Section-->
        <section class="py-5">
            <div class="container px-4 px-lg-5 mt-3">
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-around">
                    <div class="form-control">
                        <!-- ==================== ADDING NEW PRODUCT ===================== -->
                        <form class="form-group horizontal" action="?do=insert" method="post" enctype="multipart/form-data">
                            <div class="form-group form-group-lg row my-2">
                                <label for="productname" class="col-sm-2 .control-label">الاسم</label>
                                <div class="col-sm-10 col-md-10">
                                    <input type="text" class="form-control" id="productname" name="productname" placeholder="ادخل اسم السيارة" required='required'>
                                </div>
                            </div>

                            <div class="form-group form-group-lg row my-2">
                                <label for="email" class="col-sm-2 .control-label">ارافق صورة</label>
                                <div class="col-sm-10 col-md-10">
                                    <input type="file" class="form-control" id="productimage" name="productimage">
                                </div>
                            </div>

                            <div class="form-group form-group-lg row my-2">
                                <label for="email" class="col-sm-2 .control-label">وصف المنتج</label>
                                <div class="col-sm-10 col-md-10">
                                    <textarea type="description" class="form-control" id="description" name="description" placeholder="ادخل وصف السيارة" required='required'>
                                </textarea>
                                </div>
                            </div>

                            <div class="form-group form-group-lg row my-2">
                                <label for="price" class="col-sm-2 .control-label">السعر</label>
                                <div class="col-sm-10 col-md-2">
                                    <input type="text" class="form-control" id="price" name="price" placeholder="سعر المركبة" required='required'>
                                </div>
                            </div>

                            <div class="form-group form-group-lg row my-2">
                                <label for="" class="col-sm-2 .control-label">نهاية المدة</label>
                                <div class="col-sm-10 col-md-10">
                                    <input type="date" class="form-control" id="end_date" name="end_date" required='required'>
                                </div>
                            </div>

                            <div class="form-group form-group-lg row my-2">
                                <label for="username" class="col-sm-2 .control-label">الحالة</label>
                                <div class="col-sm-10 col-md-10">
                                    <input type="text" class="form-control" id="status" name="status" placeholder="ادخل حالة السيارة (جيدة ، ممتازة)" required='required'>
                                </div>
                            </div>

                            <div class="form-group form-group-lg row my-2">
                                <div class="col-sm-2 col-md-2"></div>
                                <div class="col-sm-10 col-md-10">
                                    <button class="btn btn-success" type="submit">
                                        <span style="font-size:18px;">
                                            +
                                        </span>
                                        اضافة
                                    </button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
        </section>


    <?php
        //  insert the data of product into database
    } elseif ($do == "insert") {

        $userid = $_SESSION['userID'];
        if ($_SERVER['REQUEST_METHOD'] == "POST") {

            $product_name = $_POST['productname'];
            $product_image = $_FILES['productimage']['name'];
            $product_desc = $_POST['description'];
            $product_price = $_POST['price'];
            $product_date = $_POST['end_date'];
            $product_status = $_POST['status'];

            $target = "upload/" . basename($product_image);

            move_uploaded_file($_FILES['productimage']['tmp_name'], $target);

            $stmt  = $dbConnection->prepare("INSERT INTO ads (productname , image  , userid , description , price , category_id , end_date , status ) 
                                                VALUES ( :product_name , :product_image , '$userid' ,:product_desc , :product_price , 1 , :product_date , :product_status )");

            $stmt->execute(array(

                'product_name' => $product_name,
                'product_image' => $product_image,
                'product_desc' => $product_desc,
                'product_price' => $product_price,
                'product_date' => $product_date,
                'product_status' => $product_status

            ));
        }
        echo "<div class='container py-5'>";
        echo "<div class='mr-5 alert alert-primary'>" . "تمت اضافة العرض بنجاح سيتم توجيهك الى صفحة الاضافة مرة اخرى" . "</div>";
        echo "</div>";

        header('refresh:3 ; dashboard.php');
    }

    ?>

    <?php

    include "indexfooter.php";

    ?>