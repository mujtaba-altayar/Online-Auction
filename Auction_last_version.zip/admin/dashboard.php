<?php
session_start();
include_once 'connection.php';
include "indexheader.php";
?>

<body dir="rtl">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="#!">
                المزاد الالكتروني
            </a>
            <form class="d-flex">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <li class="nav-item">
                        <?php

                        if (isset($_SESSION['user'])) {
                            echo '<a class="nav-link text-bg-danger rounded-2" href="logout.php"> تسجيل خروج ';
                            echo "</a>";
                        } else {
                            echo '<a class="nav-link" href="login.php"> تسجيل دخول' . '</a>';

                        }
                        ?>
                    </li>
                </ul>
            </form>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div style="flex-direction: row-reverse;" class="collapse navbar-collapse" id="navbarSupportedContent">
                <form class="d-flex">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link" href="viewfurnature.php">الاثاثات</a></li>
                        <li class="nav-item"><a class="nav-link" href="viewcars.php">السيارات</a></li>
                        <li class="nav-item"><a class="nav-link" href="viewelectronics.php">الاجهزة الالكترونية</a></li>
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="dashboard.php">الرئيسية</a></li>
                    </ul>
                </form>
            </div>
        </div>
    </nav>

    <!-- Header-->
    <header class="bg-dark py-5">
        <div class="container px-3 px-lg-3 my-2">
            <div class="text-center text-white">
                <h1 class="display-4 fw-bolder">الرئيسية</h1>
                <p class="lead fw-normal text-white-50 mb-0">
                    مرحبا بك <span style="color:goldenrod;">
                        <?php

                        if (isset($_SESSION['user'])) {
                            echo $_SESSION['user'];
                        } else {
                            echo "عزيزنا الزائر";
                        }

                        ?>
                    </span>
                    في ادارة المزاد الالكتروني
                </p>
            </div>
        </div>
    </header>


    <section class="py-5">
        <div class="container px-4 px-lg-5 mt-5">
            <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">


                <a href="furn_manage.php?do=Add" style="text-decoration: none;">
                    <div class="card text-black bg- mb-3" style="max-width: 18rem;">
                        <div class="card-header">
                            <span style="font-size : 25px;">+</span>
                            اضافة اثاث للمزاد
                        </div>
                        <div class="card-body">
                            <h5>معرض الاثاثات </h5>
                        </div>
                    </div>
                </a>

                <a href="car_manage.php?do=Add" style="text-decoration : none;">
                    <div class="card text-white bg-warning mb-3" style="max-width: 18rem;">
                        <div class="card-header">
                            <span style="font-size : 25px;">+</span>
                           اضافة سيارة للمزاد
                        </div>
                        <div class="card-body">
                            <h5>معرض السيارات</h5>
                        </div>
                    </div>
                </a>

                <a href="electronics_manage.php?do=Add" style="text-decoration:none;">
                    <div class="card text-white bg-success mb-3" style="max-width: 18rem;">
                        <div class="card-header">
                            <span style="font-size : 25px;">+</span>
                            اضافة جهاز للمزاد
                        </div>
                        <div class="card-body">
                            <h5>معرض الاجهزة الالكترونية</h5>
                        </div>
                    </div>
                </a>

                <a href="viewlistofads.php" style="text-decoration: none;">
                    <div class="card text-white bg-secondary mb-3" style="max-width: 18rem;">
                        <div class="card-header">
                            <span style="font-size : 25px;">+</span>
                             المعروضات الاخيرة
                        </div>
                        <div class="card-body">
                            <h5>  عروض المزايدات المتاحة</h5>
                        </div>
                    </div>
                </a>


                <!-- <div class="col mb-5">
                    <div class="card h-100">
                        <img class="card-img-top" src="images/AMG.jpg" alt="..." />
                        <div class="card-body p-4">
                            <div class="text-center">
                                <h5 class="fw-bolder">Mercedece AMG</h5>
                                السعر الابتدائي
                                <span class="text-danger">SD 37.300.000</span>
                            </div>
                        </div>
                        <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                            <div class="text-center"><a class="btn btn-outline-success mt-auto" href="#">عرض المزيد</a></div>
                        </div>
                    </div>
                </div> -->

    </section>
    <?php

    include "indexfooter.php";

    ?>