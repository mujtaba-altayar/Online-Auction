<?php
// Handeling Connection to the Database using PDO  ... 
$dsn = 'mysql:host=localhost;dbname=auction';
$user_name = "root";
$password = "";

try {
    $dbConnection  = new PDO($dsn, $user_name, $password );
    $dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $exception) {
    echo "failed to connect to the database" . $exception->getMessage();
}
