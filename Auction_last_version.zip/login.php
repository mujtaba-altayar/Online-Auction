<?php
session_start();

include "connection.php";

include "./inc/loginheader.php"; // this file contains database connection


if ($_SERVER['REQUEST_METHOD'] == 'POST' ) {

	$user_name = $_POST['name'];

    $userpassword = $_POST['password'];

    $query_statement = "SELECT userID , username , password FROM users WHERE username = ? AND status != 1 LIMIT 1 ";

    $result = $dbConnection->prepare($query_statement);

    $result->execute(array(
        $user_name
    ));

    $row = $result->fetch();

    $counter = $result->rowCount();

    if ($counter > 0) {
		$_SESSION['email'] = $row['eamil']; // register userID
		
        $_SESSION['user'] = $row['username'];
        header("Location: index.php");
        exit();
    }

}


if ($_SERVER['REQUEST_METHOD'] == 'POST' ) {

	$user_name = $_POST['name'];

    $userpassword = $_POST['password'];

    $query_statement = "SELECT * FROM users WHERE username = ? AND status = 1 LIMIT 1";

    $result = $dbConnection->prepare($query_statement);

    $result->execute(array(
        $user_name
    ));

    $row = $result->fetch();

    $counter = $result->rowCount();

    if ($counter > 0) {
        $_SESSION['user'] = $row['username'];
		$_SESSION['userID'] =$row['userID'];
        header("Location: /auction/admin/dashboard.php");
        exit();
    }
}
?>


<body class="img js-fullheight" style="background-image: url(images/bg.jpg);">
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-5">
					<h1 class="heading-section">المزاد الالكتروني</h1>
					<h1 class="text-white" style="letter-spacing: 7px;">E-Auction</h1>
				</div>
			</div>
			<div class="row justify-content-center">
				<div class="col-md-6 col-lg-4">
					<div class="login-wrap p-0">
						<!-- Title of the login form -->
						<h3 class="mb-4 text-center">تسجيل الدخول</h3>

						<!-- form start -->
						<form class="signin-form" action="<?php $_SERVER['PHP_SELF']; ?>" method='POST'>
							<!-- username'POST'	-->
							<div class="form-group">
								<input type="text" class="form-control text-center" name="name" placeholder="اسم المستخدم" required autocomplete="off">
							</div>

							<!-- password -->
							<div class="form-group">
								<input id="password-field" type="password" name="password" class="form-control text-center" placeholder="كلمة المرور" required>
							</div>

							<!-- Login Button -->
							<div class="form-group">
								<button type="submit" class="form-control btn submit px-3" name="login" style="background-color:#1a7e11;">
									<h5 class="text-white">دخول</h5>
								</button>
							</div>
						</form>
						<!-- form ends -->

					</div>
				</div>
			</div>
		</div>
	</section>


	<?php

	include "./inc/loginfooter.php";

	?>
</body>

</html>