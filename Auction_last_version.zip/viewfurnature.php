<?php
session_start();
include_once 'connection.php';
include "indexheader.php";
?>

<body dir="rtl">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="#!">
                المزاد الالكتروني
            </a>
            <form class="d-flex">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <li class="nav-item">
                        <?php

                        if (isset($_SESSION['user'])) {
                            echo '<a class="nav-link text-bg-danger rounded-2" href="logout.php"> تسجيل خروج ';
                            echo "</a>";
                        } else {
                            echo '<a class="nav-link text-bg-success rounded-2" href="login.php"> تسجيل دخول' . '</a>';
                        }
                        ?>
                    </li>
                </ul>
            </form>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div style="flex-direction: row-reverse;" class="collapse navbar-collapse" id="navbarSupportedContent">
                <form class="d-flex">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link" href="viewfurnature.php" style="text-decoration: none;">الاثاثات</a></li>
                        <li class="nav-item"><a class="nav-link" href="viewcars.php">السيارات</a></li>
                        <li class="nav-item"><a class="nav-link" href="viewelectronics.php">الاجهزة الالكترونية</a></li>
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="index.php">الرئيسية</a></li>
                    </ul>
                </form>
            </div>
        </div>
    </nav>

    <header class="bg-dark py-5">
        <div class="container px-3 px-lg-3 my-2">
            <div class="text-center text-white">
                <h1 class="display-4 fw-bolder">معرض الاثاثات</h1>
            </div>
            <p class="lead fw-normal text-center text-warning mb-0">
                اسس منزلك بارقى الاثاثات العصرية
            </p>
        </div>
    </header>


    <section class="py-5">
        <div class="container px-4 px-lg-5 mt-5">
            <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">

                <?php

                $stmt = $dbConnection->prepare("SELECT productName , image , description , price , end_date , status FROM ads where category_id = 2 ORDER BY end_date DESC LIMIT 10");

                $stmt->execute();

                $rows = $stmt->fetchAll();

                if (!empty($rows)) {
                    foreach ($rows as $row) {
                ?>

                        <div class='col mb-5'>
                            <div class='card h-auto'>
                                <img class='card-img-top' src='admin/upload/<?php echo $row['image']; ?>'>
                                <div class='card-body p-4'>
                                    <div class='text-center'>
                                        <h5 class='fw-bolder'><?php echo $row['productName'];  ?></h5>
                                        السعر الابتدائي &nbsp;&nbsp;
                                        <span class='text-danger'>
                                            <?php echo  $row['price'] . "جنيه";  ?>
                                        </span>
                                    </div>
                                    <div class='text-right'>
                                        <h5>
                                            <?php echo $row['description']; ?>
                                        </h5>
                                    </div>
                                </div>
                                <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                    <div class="text-center"><?php echo ' انتهاء العرض'; ?>&nbsp;&nbsp;&nbsp;<?php echo '<span style="color:red;">' . $row['end_date']; ?></div>
                                </div>
                                <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                    <div class="text-center"><a class="btn btn-outline-warning mt-auto" href="#">مزايدة</a></div>
                                </div>
                            </div>
                        </div>
                <?php
                    }
                }
                ?>
            </div>
        </div>

        <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
            <div class="text-center"><a class="btn btn-primary mt-auto w-25" href="index.php">رجوع</a></div>
        </div>
    </section>
    <?php

    include "indexfooter.php";

    ?>